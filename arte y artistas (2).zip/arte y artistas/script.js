import * as THREE from 'three';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.z = 6;
const renderer = new THREE.WebGLRenderer({ alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

//particulas
const particleCount = 1500;
const positions = new Float32Array(particleCount * 3);

for (let i = 0; i < particleCount * 3; i++) {
  positions[i] = (Math.random() - 0.5) * 50;
}
const geometryParticles = new THREE.BufferGeometry();
geometryParticles.setAttribute(
  "position",
  new THREE.BufferAttribute(positions, 3)
);
const materialParticles = new THREE.PointsMaterial({
  color: 0xffffff,
  size: 0.03,
});
const particles = new THREE.Points(geometryParticles, materialParticles);
scene.add(particles);

//esfera
const geometrySphere = new THREE.SphereGeometry(1, 32, 32);
const materialSphere = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  metalness: 0.6,
  roughness: 0.3,
});
const sphere = new THREE.Mesh(geometrySphere, materialSphere);
scene.add(sphere);

//luces
const light = new THREE.PointLight(0xffffff, 1);
light.position.set(5, 5, 5);
scene.add(light);
scene.add(new THREE.AmbientLight(0x404040));

let t = 0;

function animate() {
  requestAnimationFrame(animate);

  // partículas
  particles.rotation.y += 0.0005;

  // esfera
  sphere.rotation.y += 0.01;
  t += 0.02;
  sphere.position.y = Math.sin(t) * 0.5;
  renderer.render(scene, camera);
}

animate();

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
