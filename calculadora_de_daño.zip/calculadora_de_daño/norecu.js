let vidaHeroe = 100;

function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pelear(nivelMonstruo) {
    let vidaMonstruo = random(30 * nivelMonstruo, 50 * nivelMonstruo);

    console.log("Monstruo nivel " + nivelMonstruo + " aparece con " + vidaMonstruo + " de vida");

    while (vidaHeroe > 0 && vidaMonstruo > 0) {

        // héroe
        let ataqueHeroe = random(10, 25);
        let esquivaMonstruo = Math.random() < 0.5;

        if (esquivaMonstruo) {
            console.log("El monstruo esquivó el ataque");
        } else {
            vidaMonstruo -= ataqueHeroe;
            console.log("Golpeas al monstruo tu daño es de:  " + ataqueHeroe);
        }

        if (vidaMonstruo <= 0) {
            console.log("Monstruo derrotado con " + vidaHeroe + " de vida restante");
            return true;
        }

        //monstruo
        let ataqueMonstruo = random(10 * nivelMonstruo, 20 * nivelMonstruo);
        let esquivaHeroe = Math.random() < 0.5;

        if (esquivaHeroe) {
            console.log("Ataque equivados por el héroe");
        } else {
            vidaHeroe -= ataqueMonstruo;
            console.log("Recibes " + ataqueMonstruo + " de daño");
        }

        console.log("Vida héroe: " + vidaHeroe);
    }

    return vidaHeroe > 0;
}

function iniciarJuego() {
    console.log("Comienza la batalla contra los monstruos");

    for (let i = 1; i <= 3; i++) {
        let gano = pelear(i);

        if (!gano) {
            console.log("falta de mana, you lost ");
            return;
        }
    }

    console.log("¡Ganaste todas las batallas!");
}