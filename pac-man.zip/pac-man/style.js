import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Pac man 
const geometry = new THREE.SphereGeometry(
  5,32,16,0,
  4.58,
  Math.PI
);

const material = new THREE.MeshBasicMaterial({
  color: 0xffff00,
  wireframe: true
});

const figura = new THREE.Mesh(geometry, material);
scene.add(figura);

camera.position.z = 40;

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

function animate() {
  requestAnimationFrame(animate);

  controls.update(); 

  renderer.render(scene, camera);
}

const geoBolita = new THREE.SphereGeometry(2.5, 20, 10);
// 🔹 material emisivo
const matBolita = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});

// 🔹 bolita principal
const figura1 = new THREE.Mesh(geoBolita, matBolita);
figura1.position.set(0, 0, 0);
scene.add(figura1);

//bolita arriba derecha
const figura2 = new THREE.Mesh(geoBolita, matBolita);
figura2.position.set(64, 0, -74);
scene.add(figura2);

// bolita arriba izquierda
const figura3 = new THREE.Mesh(geoBolita, matBolita);
figura3.position.set(-64, 0, -74);
scene.add(figura3);

// bolita abajo derecha
const figura60 = new THREE.Mesh(geoBolita, matBolita);
figura60.position.set(64, 0, 24);
scene.add(figura60);

// bolita abajo izquierda
const figura61 = new THREE.Mesh(geoBolita, matBolita);
figura61.position.set(-64, 0, 24);
scene.add(figura61);

//paredes 
// Medidas
const width = 30.0;  
const height = 8.0;  
const depth = 2.5;  

const widthSegments = 4;  
const heightSegments = 4;  
const depthSegments = 4;  

// Geometría
const geometry4 = new THREE.BoxGeometry(
  width,
  height,
  depth,
  widthSegments,
  heightSegments,
  depthSegments
);

// Material
const material4 = new THREE.MeshBasicMaterial({
  color:  0x0000ff,
  wireframe: true
});

// Figura
const figura4 = new THREE.Mesh(geometry4, material4);

// Posición
figura4.position.z = 10;
scene.add(figura4);

//
const width5 = 30.0;  
const height5 = 8.0;  
const depth5 = 2.5;  
const geometry5 = new THREE.BoxGeometry(width5, height5, depth5);
const material5 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura5 = new THREE.Mesh(geometry5, material5);
figura5.position.z = -10;
scene.add(figura5);

//
const width6 = 2.5;  
const height6 = 8.0;  
const depth6 = 20.0;  
const geometry6 = new THREE.BoxGeometry(width6, height6, depth6);
const material6 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura6 = new THREE.Mesh(geometry6, material6);
figura6.position.x = 16;
figura6.position.z = -20;
scene.add(figura6);

//
const width7 = 30.0;  
const height7 = 8.0;  
const depth7 = 2.5;  
const geometry7 = new THREE.BoxGeometry(width7, height7, depth7);
const material7 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura7 = new THREE.Mesh(geometry7, material7);
figura7.position.z = -30;
scene.add(figura7);

//
const width8 = 2.5;  
const height8 = 8.0;  
const depth8 = 20.0;  
const geometry8 = new THREE.BoxGeometry(width8, height8, depth8);
const material8 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura8 = new THREE.Mesh(geometry8, material8);
figura8.position.x = -16;
figura8.position.z = -20;
scene.add(figura8);

//
const width9 = 2.5;  
const height9 = 8.0;  
const depth9 = 10.0;  
const geometry9 = new THREE.BoxGeometry(width9, height9, depth9);
const material9 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura9 = new THREE.Mesh(geometry9, material9);
figura9.position.z = 15;
figura9.position.x = 0;
scene.add(figura9);

//Gemelo1 horizontal-pos1
const width10 = 15.0;  
const height10 = 8.0;  
const depth10 = 2.5;  
const geometry10 = new THREE.BoxGeometry(width10, height10, depth10);
const material10 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura10 = new THREE.Mesh(geometry10, material10);
figura10.position.z = 20;
figura10.position.x = 22;
scene.add(figura10);

//gemelo2 horizontal-pos1
const width11 = 15.0;  
const height11 = 8.0;  
const depth11 = 2.5;  
const geometry11 = new THREE.BoxGeometry(width11, height11, depth11);
const material11 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura11 = new THREE.Mesh(geometry11, material11);
figura11.position.z = 20;
figura11.position.x = -22;
scene.add(figura11);

// gemelo2 horizontal-pos2
const width12 = 15.0;  
const height12 = 8.0;  
const depth12 = 2.5;  
const geometry12 = new THREE.BoxGeometry(width12, height12, depth12);
const material12 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura12 = new THREE.Mesh(geometry12, material12);
figura12.position.z = -45;
figura12.position.x = -22;
scene.add(figura12);

// gemelo1 horizontal-pos2
const width13 = 15.0;  
const height13 = 8.0;
const depth13 = 2.5;
const geometry13 = new THREE.BoxGeometry(width13, height13, depth13);
const material13 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura13 = new THREE.Mesh(geometry13, material13);
figura13.position.z = -45;
figura13.position.x = 22;
scene.add(figura13);

//Gemelo1 vertical-pos1
const width14 = 2.5;  
const height14 = 8.0;  
const depth14 = 33.0;  
const geometry14 = new THREE.BoxGeometry(width14, height14, depth14);
const material14 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura14 = new THREE.Mesh(geometry14, material14);
figura14.position.x =  30;
figura14.position.z = -43;
scene.add(figura14);

//gemelo2 vertical-pos1
const width15 = 2.5;  
const height15 = 8.0;  
const depth15 = 33.0;  
const geometry15 = new THREE.BoxGeometry(width15, height15, depth15);
const material15 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura15 = new THREE.Mesh(geometry15, material15);
figura15.position.x =  -30;
figura15.position.z = -43;
scene.add(figura15);

//gemelo1 side1
const width16 = 2.5;  
const height16 = 8.0;  
const depth16 = 20.0;  
const geometry16 = new THREE.BoxGeometry(width16, height16, depth16);
const material16 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura16 = new THREE.Mesh(geometry16, material16);
figura16.position.x = -30;
figura16.position.z = 0;
scene.add(figura16);

//gemelo2 side1
const width17 = 2.5;  
const height17 = 8.0;  
const depth17 = 20.0;  
const geometry17 = new THREE.BoxGeometry(width17, height17, depth17);
const material17 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura17 = new THREE.Mesh(geometry17, material17);
figura17.position.x = 30;
scene.add(figura17);

//gemelo1 side2
const width18 = 2.5;  
const height18 = 8.0;  
const depth18 = 20.0;  
const geometry18 = new THREE.BoxGeometry(width18, height18, depth18);
const material18 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura18 = new THREE.Mesh(geometry18, material18);
figura18.position.x = -42;
scene.add(figura18);

//gemelo2 side2
  const width19 = 2.5;  
  const height19 = 8.0;  
  const depth19 = 20.0;  
  const geometry19 = new THREE.BoxGeometry(width19, height19, depth19);
  const material19 = new THREE.MeshStandardMaterial({
    color:  0x0000ff,
    emissive:  0x0000ff,
    emissiveIntensity: 1
  });

  const figura19 = new THREE.Mesh(geometry19, material19);
  figura19.position.x = 42;
  scene.add(figura19);

//gemelo1 side3
  const width20 = 2.5;  
  const height20 = 8.0;  
  const depth20 = 18.0;  
  const geometry20 = new THREE.BoxGeometry(width20, height20, depth20);
  const material20 = new THREE.MeshStandardMaterial({
    color:  0x0000ff,
    emissive:  0x0000ff,
    emissiveIntensity: 1
  });

  const figura20 = new THREE.Mesh(geometry20, material20);
  figura20.position.x = -42;
  figura20.position.z = -35;
  scene.add(figura20);

//gemelo2 side3
  const width21 = 2.5;  
  const height21 = 8.0;  
  const depth21 = 18.0;  
  const geometry21 = new THREE.BoxGeometry(width21, height21, depth21);
  const material21 = new THREE.MeshStandardMaterial({
    color:  0x0000ff,
    emissive:  0x0000ff,
    emissiveIntensity: 1
  });

  const figura21 = new THREE.Mesh(geometry21, material21);
  figura21.position.x = 42;
  figura21.position.z = -35;
  scene.add(figura21);

//pasillo1.1
const width22 = 30.0;  
const height22 = 8.0;  
const depth22 = 2.5;  
const geometry22 = new THREE.BoxGeometry(width22, height22, depth22);
const material22 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura22 = new THREE.Mesh(geometry22, material22);
figura22.position.z = -10;
figura22.position.x = 57;
scene.add(figura22);

//pasillo2.1
const width23 = 30.0;  
const height23 = 8.0;  
const depth23 = 2.5;  
const geometry23 = new THREE.BoxGeometry(width23, height23, depth23);
const material23 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura23 = new THREE.Mesh(geometry23, material23);
figura23.position.z = -26;
figura23.position.x = 57;
scene.add(figura23);

//pasillo1-contra1
const width24 = 30.0;  
const height24 = 8.0;  
const depth24 = 2.5;  
const geometry24 = new THREE.BoxGeometry(width24, height24, depth24);
const material24 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura24 = new THREE.Mesh(geometry24, material24);
figura24.position.z = -10;
figura24.position.x = -57;
scene.add(figura24);

//pasillo2-contra1
const width25 = 30.0;  
const height25 = 8.0;  
const depth25 = 2.5;  
const geometry25 = new THREE.BoxGeometry(width25, height25, depth25);
const material25 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura25 = new THREE.Mesh(geometry25, material25);
figura25.position.z = -26;
figura25.position.x = -57;
scene.add(figura25);

//pasillo1.2
const width26 = 30.0;  
const height26 = 8.0;  
const depth26 = 2.5;  
const geometry26 = new THREE.BoxGeometry(width26, height26, depth26);
const material26 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura26 = new THREE.Mesh(geometry26, material26);
figura26.position.z = -44;
figura26.position.x = 57;
scene.add(figura26);

//pasillo2.2
const width27 = 30.0;  
const height27 = 8.0;  
const depth27 = 2.5;  
const geometry27 = new THREE.BoxGeometry(width27, height27, depth27);
const material27 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura27 = new THREE.Mesh(geometry27, material27);
figura27.position.z = 10;
figura27.position.x = 57;
scene.add(figura27);

//pasillo1-contra2
const width28 = 30.0;  
const height28 = 8.0;  
const depth28 = 2.5;  
const geometry28 = new THREE.BoxGeometry(width28, height28, depth28);
const material28 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura28 = new THREE.Mesh(geometry28, material28);
figura28.position.z = -44;
figura28.position.x = -57;
scene.add(figura28);

//pasillo2-contra2
const width29 = 30.0;  
const height29 = 8.0;  
const depth29 = 2.5;  
const geometry29 = new THREE.BoxGeometry(width29, height29, depth29);
const material29 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura29 = new THREE.Mesh(geometry29, material29);
figura29.position.z = 10;
figura29.position.x = -57;
scene.add(figura29);

//t1- horizontal
const width30 = 12.0;  
const height30 = 8.0;  
const depth30 = 2.5;  
const geometry30 = new THREE.BoxGeometry(width30, height30, depth30);
const material30 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura30 = new THREE.Mesh(geometry30, material30);
figura30.position.z = 20;
figura30.position.x = 46;
scene.add(figura30);

//t2-horrizontal
const width31 = 12.0;  
const height31 = 8.0;  
const depth31 = 2.5;  
const geometry31 = new THREE.BoxGeometry(width31, height31, depth31);
const material31 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura31 = new THREE.Mesh(geometry31, material31);
figura31.position.z = 20;
figura31.position.x = -46;
scene.add(figura31);

//t1-vertical
const width32 = 2.5;  
const height32 = 8.0;  
const depth32 = 15.0;  
const geometry32 = new THREE.BoxGeometry(width32, height32, depth32);
const material32 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura32 = new THREE.Mesh(geometry32, material32);
figura32.position.z = 27;
figura32.position.x = 41;
scene.add(figura32);

//t2-vertical
const width33 = 2.5;  
const height33 = 8.0;  
const depth33 = 15.0;  
const geometry33 = new THREE.BoxGeometry(width33, height33, depth33);
const material33 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura33 = new THREE.Mesh(geometry33, material33);
figura33.position.z = 27;
figura33.position.x = -41;
scene.add(figura33);

//gemelitos1
const width35 = 12.0;  
const height35 = 8.0;  
const depth35 = 2.5;  
const geometry35 = new THREE.BoxGeometry(width35, height35, depth35);
const material35 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura35 = new THREE.Mesh(geometry35, material35);
figura35.position.z = 35;
figura35.position.x = 67;
scene.add(figura35);

//gemelitos2
const width36 = 12.0;  
const height36 = 8.0;  
const depth36 = 2.5;  
const geometry36 = new THREE.BoxGeometry(width36, height36, depth36);
const material36 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura36 = new THREE.Mesh(geometry36, material36);
figura36.position.z = 35;
figura36.position.x = -67;
scene.add(figura36);

//unth1
const width37 = 30.0;  
const height37 = 8.0;  
const depth37 = 2.5;  
const geometry37 = new THREE.BoxGeometry(width37, height37, depth37);
const material37 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura37 = new THREE.Mesh(geometry37, material37);
figura37.position.z = 32;
scene.add(figura37);

//untv1
const width38 = 2.5;  
const height38 = 8.0;  
const depth38 = 10.0;  
const geometry38 = new THREE.BoxGeometry(width38, height38, depth38);
const material38 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura38 = new THREE.Mesh(geometry38, material38);
figura38.position.z = 36;
scene.add(figura38);

//unth2
const width39 = 30.0;  
const height39 = 8.0;  
const depth39 = 2.5;  
const geometry39 = new THREE.BoxGeometry(width39, height39, depth39);
const material39 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura39 = new THREE.Mesh(geometry39, material39);
figura39.position.z = -62;
scene.add(figura39);

//untv2
const width40 = 2.5;  
const height40 = 8.0;  
const depth40 = 16.0;  
const geometry40 = new THREE.BoxGeometry(width40, height40, depth40);
const material40 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura40 = new THREE.Mesh(geometry40, material40);
figura40.position.z = -54;
scene.add(figura40);

//t3-horizontal
  const width41 = 12.0;  
  const height41 = 8.0;  
  const depth41 = 2.5;  
  const geometry41 = new THREE.BoxGeometry(width41, height41, depth41);
  const material41 = new THREE.MeshStandardMaterial({
    color:  0x0000ff,
    emissive:  0x0000ff,
    emissiveIntensity: 1
  });
  const figura41 = new THREE.Mesh(geometry41, material41);
  figura41.position.z = -60;
  figura41.position.x = 47;
  scene.add(figura41);

//t4-horizontal
  const width42 = 12.0;  
  const height42 = 8.0;  
  const depth42 = 2.5;  
  const geometry42 = new THREE.BoxGeometry(width42, height42, depth42);
  const material42 = new THREE.MeshStandardMaterial({
    color:  0x0000ff,
    emissive:  0x0000ff,
    emissiveIntensity: 1
  });
  const figura42 = new THREE.Mesh(geometry42, material42);
  figura42.position.z = -60;
  figura42.position.x = -47;
  scene.add(figura42);

//pipi 
const width43 = 2.5;  
const height43 = 8.0;  
const depth43 = 16.0;  
const geometry43 = new THREE.BoxGeometry(width43, height43, depth43);
const material43 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura43 = new THREE.Mesh(geometry43, material43);
figura43.position.x = -30;
figura43.position.z = 43;
scene.add(figura43);

//pipi2
const width44 = 2.5;  
const height44 = 8.0;  
const depth44 = 16.0;
const geometry44 = new THREE.BoxGeometry(width44, height44, depth44);
const material44 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura44 = new THREE.Mesh(geometry44, material44);
figura44.position.x = 30;
figura44.position.z = 43;
scene.add(figura44);

//pipi1-v
const width45 = 45.0;  
const height45 = 8.0;  
const depth45 = 2.5;  
const geometry45 = new THREE.BoxGeometry(width45, height45, depth45);
const material45 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura45 = new THREE.Mesh(geometry45, material45);
figura45.position.x = -35;
figura45.position.z = 52;
scene.add(figura45);

//pipi2-v
const width46 = 45.0;  
const height46 = 8.0;  
const depth46 = 2.5;  
const geometry46 = new THREE.BoxGeometry(width46, height46, depth46);
const material46 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura46 = new THREE.Mesh(geometry46, material46);
figura46.position.x = 35;
figura46.position.z = 52;
scene.add(figura46);

//pared1-abajo
const width34 = 2.5;  
const height34 = 8.0;  
const depth34 = 55.0;  
const geometry34 = new THREE.BoxGeometry(width34, height34, depth34);
const material34 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura34 = new THREE.Mesh(geometry34, material34);
figura34.position.z = 36;
figura34.position.x = 72;
scene.add(figura34);

//pared2-abajo
const width47 = 2.5;  
const height47 = 8.0;  
const depth47 = 55.0;  
const geometry47 = new THREE.BoxGeometry(width47, height47, depth47);
const material47 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura47 = new THREE.Mesh(geometry47, material47);
figura47.position.z = 36;
figura47.position.x = -72;
scene.add(figura47);

//pared1-arriba
const width49 = 2.5;  
const height49 = 8.0;  
const depth49 = 55.0;  
const geometry49 = new THREE.BoxGeometry(width49, height49, depth49);
const material49 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura49 = new THREE.Mesh(geometry49, material49);
figura49.position.z = -72;
figura49.position.x = 72;
scene.add(figura49);

//pared2-arriba
const width50 = 2.5;  
const height50 = 8.0;  
const depth50 = 55.0;  
const geometry50 = new THREE.BoxGeometry(width50, height50, depth50);
const material50 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura50 = new THREE.Mesh(geometry50, material50);
figura50.position.z = -72;
figura50.position.x = -72;
scene.add(figura50);

//piso1- abajo
const width48 = 146.0;  
const height48 = 8.0;  
const depth48 = 2.5;  
const geometry48 = new THREE.BoxGeometry(width48, height48, depth48);
const material48 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura48 = new THREE.Mesh(geometry48, material48);
figura48.position.z =64;
scene.add(figura48);

//piso2-arriba
const width51= 146.0;  
const height51 = 8.0;  
const depth51 = 2.5;  
const geometry51 = new THREE.BoxGeometry(width51, height51, depth51);
const material51 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura51 = new THREE.Mesh(geometry51, material51);
figura51.position.z = -100;
scene.add(figura51);

//punta
const width52 = 2.5;  
const height52 = 8.0;  
const depth52 = 14.0;  
const geometry52 = new THREE.BoxGeometry(width52, height52, depth52);
const material52 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});

const figura52 = new THREE.Mesh(geometry52, material52);
figura52.position.z = -94;
scene.add(figura52);

//yano
const width53 = 14.5;  
const height53 = 8.0;  
const depth53 = 7.0;
const geometry53 = new THREE.BoxGeometry(width53, height53, depth53);
const material53 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura53 = new THREE.Mesh(geometry53, material53);
figura53.position.z = -78;
figura53.position.x = 48;
scene.add(figura53);

//yano2
const width54 = 14.5;  
const height54 = 8.0;  
const depth54 = 7.0;
const geometry54 = new THREE.BoxGeometry(width54, height54, depth54);
const material54 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura54 = new THREE.Mesh(geometry54, material54);
figura54.position.z = -78;
figura54.position.x = -48;
scene.add(figura54);

//rectangulo1
const width55 = 20.0;  
const height55 = 8.0;  
const depth55 = 7.0;
const geometry55 = new THREE.BoxGeometry(width55, height55, depth55);
const material55 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura55 = new THREE.Mesh(geometry55, material55);
figura55.position.z = -78;
figura55.position.x = 20;
scene.add(figura55);

//rectangulo2
const width56 = 20.0;  
const height56 = 8.0;  
const depth56 = 7.0;
const geometry56 = new THREE.BoxGeometry(width56, height56, depth56);
const material56 = new THREE.MeshStandardMaterial({
  color:  0x0000ff,
  emissive:  0x0000ff,
  emissiveIntensity: 1
});
const figura56 = new THREE.Mesh(geometry56, material56);
figura56.position.z = -78;
figura56.position.x = -20;
scene.add(figura56);


//fantasmas
const matOjoBlanco = new THREE.MeshBasicMaterial({ color: 0xffffff });
const matOjoNegro = new THREE.MeshBasicMaterial({ color: 0x000000 });

//ojos
function crearOjos() {
  const ojos = new THREE.Group();

  const o1 = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 12), matOjoBlanco);
  const o2 = o1.clone();
  o1.position.set(-1, 2, 3);
  o2.position.set(1, 2, 3);

  const p1 = new THREE.Mesh(new THREE.SphereGeometry(0.90, 12, 12), matOjoNegro);
  const p2 = p1.clone();
  p1.position.set(-1, 2, 3.5);
  p2.position.set(1, 2, 3.5);

  ojos.add(o1, o2, p1, p2);
  return ojos;
}

//C.Fantasmas
function crearFantasma(color, x, z) {
  const material = new THREE.MeshStandardMaterial({
    color: color,
    emissive: color,
    emissiveIntensity: 1.5
  });
  const cabeza = new THREE.Mesh(
    new THREE.SphereGeometry(3, 16, 16),
    material
  );
  cabeza.position.y = 2;
  const cuerpo = new THREE.Mesh(
    new THREE.CylinderGeometry(3, 3, 4, 16),
    material
  );
  cuerpo.position.y = -1;
  const fantasma = new THREE.Group();
  fantasma.add(cabeza, cuerpo, crearOjos());
  fantasma.position.set(x, 0, z);
  return fantasma;
}
//fantasmas
scene.add(crearFantasma(0xff0000, 8, 16));     // rojo
scene.add(crearFantasma(0xffb8ff, -6, -20));   // rosa
scene.add(crearFantasma(0x00ffff, 20, 40));    // cian
scene.add(crearFantasma(0xffa500, -36, -58));  // naranja

//bolitas
const geoBolita99 = new THREE.SphereGeometry(2, 30, 10);

const matBolita99 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});

const cantidad = 4;    
const separacion = 8;    

for (let i = 0; i < cantidad; i++) {
  const bolita = new THREE.Mesh(geoBolita99, matBolita99);
  bolita.position.set(i * separacion, 0, 0);
  
  scene.add(bolita);
}
//MITAD inferior pequeño
const geoBolita2 = new THREE.SphereGeometry(2, 20, 10);
const matBolita2 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad2 = 8;    
const separacion2 = 8;    
for (let i = 0; i < cantidad2; i++) {
  const bolita = new THREE.Mesh(geoBolita2, matBolita2);
  bolita.position.set(-28 + i * separacion2, 0, 27 );
  scene.add(bolita);
}

const geoBolita3 = new THREE.SphereGeometry(2, 20, 10);
const matBolita3 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad3 = 6;    
const separacion3 = 8;    
for (let i = 0; i < cantidad3; i++) {
  const bolita = new THREE.Mesh(geoBolita3, matBolita3);
  bolita.position.set(-20 + i * separacion3, 0, -38 );
  scene.add(bolita);
}

//mitad superior 
const geoBolita4 = new THREE.SphereGeometry(2, 20, 10);
const matBolita4 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad4 = 14;    
const separacion4 = 8;    
for (let i = 0; i < cantidad4; i++) {
  const bolita = new THREE.Mesh(geoBolita4, matBolita4);
  bolita.position.set(-53 + i * separacion4, 0, -70);
  scene.add(bolita);
}
//superior 
const geoBolita5 = new THREE.SphereGeometry(2, 20, 10);
const matBolita5 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad5  = 8;    
const separacion5 = 8;    
for (let i = 0; i < cantidad5; i++) {
  const bolita = new THREE.Mesh(geoBolita5, matBolita5);
  bolita.position.set(-64 + i * separacion5, 0, -90);
  scene.add(bolita);
}

const geoBolita6 = new THREE.SphereGeometry(2, 20, 10);
const matBolita6 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad6  = 8;    
const separacion6 = 8;    
for (let i = 0; i < cantidad6; i++) {
  const bolita = new THREE.Mesh(geoBolita6, matBolita6);
  bolita.position.set(8 + i * separacion6, 0, -90);
  scene.add(bolita);
}
//inferior largo 
const geoBolita7 = new THREE.SphereGeometry(2, 20, 10);
const matBolita7 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad7  = 17;    
const separacion7 = 8;    
for (let i = 0; i < cantidad7; i++) {
  const bolita = new THREE.Mesh(geoBolita7, matBolita7);
  bolita.position.set(-64 + i * separacion7, 0, 58);
  scene.add(bolita);
}
//laterales 
//izquierdo
const geoBolita8 = new THREE.SphereGeometry(2, 20, 10);
const matBolita8 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad8 = 14;    
const separacion8 = 8;    
for (let i = 0; i < cantidad8; i++) {
  const bolita = new THREE.Mesh(geoBolita8, matBolita8);
  bolita.position.set(-36 , 0, -60 + i * separacion8);
  scene.add(bolita);
}
//derecho
const geoBolita9 = new THREE.SphereGeometry(2, 20, 10);
const matBolita9 = new THREE.MeshStandardMaterial({
  color: 0xffff00,
  emissive: 0xffff00,
  emissiveIntensity: 2
});
const cantidad9 = 14;    
const separacion9 = 8;    
for (let i = 0; i < cantidad9; i++) {
  const bolita = new THREE.Mesh(geoBolita9, matBolita9);
  bolita.position.set(37 , 0, -61 + i * separacion9);
  scene.add(bolita);
}
animate();